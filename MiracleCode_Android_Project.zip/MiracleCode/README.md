# Miracle Code — Мобильная мультиагентная среда разработки и оркестрации ИИ на Android

**Miracle Code** — приложение на базе **Jetpack Compose (Material Design 3 / Material You)** и **Clean Architecture + MVI**, объединяющее мультиагентную оркестрацию ИИ со встроенным скрытым редактором кода и локальной Linux/PRoot-песочницей.

## Ключевые архитектурные модули
1. **Material 3 ("Clean First")**: Dynamic Color (Android 12+), темы Light / Dark / AMOLED Black (`#000000`), пружинные переходы (`spring`).
2. **Hidden Sandbox Architecture (`HiddenSandboxBridge.kt`)**: Встроенный файловый менеджер, редактор кода, PRoot/sh-терминал и система чекпоинтов (`Snapshots & Time Travel`). Скрыты по умолчанию и разблокируются только через `Настройки -> Расширенные -> Режим разработчика -> Показать внутренний редактор и терминал`.
3. **Провайдеры и Автозагрузка Моделей (`ProviderManager.kt`, `EncryptedKeyVault.kt`)**: Пресеты для OpenAI, Anthropic, Google Gemini, OpenRouter, DeepSeek, Groq, Mistral, xAI, Ollama + кастомные провайдеры с `Base URL` и HTTP-заголовками. Автоматический `GET /v1/models` и хранение ключей в `EncryptedSharedPreferences` (Android Keystore).
4. **Двухуровневая система усилий (`EffortEngine.kt`)**:
   - **Model Effort**: `Low`, `Medium`, `High`, `Max`, `Custom Budget` (`reasoning_effort`, `thinking.budget_tokens`, `temperature`/`top_p`).
   - **Layer Effort**: `Off`, `Layer 1: Structured`, `Layer 2: Deep Critique`, `Layer 3: Godlike Exhaustive` (независимая многослойная системная инъекция).
5. **5 Режимов Оркестрации (`OrchestrationEngine.kt`)**:
   - **Solo Mode**: 1 модель.
   - **Side-by-Side Mode**: параллельный запуск 2+ моделей со сплит-каруселью и кнопкой «Выбрать лучший ответ как основу».
   - **Agent Mix Mode**: 2+ агентов в едином общем контексте (дебаты и код-ревью).
   - **Orchestra Mode**: 1 Главный агент (Orchestrator) + от 3 до 5 строго изолированных Субагентов (Backend, UI/UX, QA, Security, Refactoring) без горизонтальных связей.
   - **Autonomous Agent Mode**: полный автономный контроль над режимами, файлами и циклом **Auto-Heal Loop** (перехват `stderr` из терминала и автоматическое исправление кода).
6. **GitHub Actions CI/CD (`.github/workflows/`)**:
   - `.github/workflows/android-ci.yml`: проверка Android Lint, запуск Unit-тестов и сборка Debug APK.
   - `.github/workflows/release-apk.yml`: автоматическая сборка подписанных Release APK и AAB при пуше тега `v*.*.*`.
