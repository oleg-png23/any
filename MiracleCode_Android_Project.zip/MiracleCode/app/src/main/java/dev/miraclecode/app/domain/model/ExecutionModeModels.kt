package dev.miraclecode.app.domain.model

import kotlinx.serialization.Serializable

/**
 * 5. Режимы работы Агентов (Execution Modes)
 */
@Serializable
enum class ExecutionMode(val title: String, val subtitle: String) {
    SOLO(
        title = "Solo Mode",
        subtitle = "1 выбранная модель отвечает на запросы или пишет код"
    ),
    SIDE_BY_SIDE(
        title = "Side-by-Side",
        subtitle = "Параллельное сравнение 2+ моделей и выбор лучшего ответа"
    ),
    AGENT_MIX(
        title = "Agent Mix",
        subtitle = "Коллаборация 2+ агентов в едином контексте (спорят и ревьюят код)"
    ),
    ORCHESTRA(
        title = "Orchestra Mode",
        subtitle = "1 Главный Архитектор + 3..5 строго изолированных Субагентов"
    ),
    AUTONOMOUS_AGENT(
        title = "Agent Mode",
        subtitle = "Полный автономный контроль над редактором, терминалом и режимами"
    )
}

@Serializable
enum class SubAgentSpecialty(val roleTitle: String, val systemFocus: String) {
    ORCHESTRATOR("Lead Architect / Orchestrator", "Декомпозиция системы, распределение изолированных ТЗ и финальная интеграция без конфликтов"),
    BACKEND("Backend & Core Engineer", "Чистая бизнес-логика, репозитории, алгоритмы, работа с сетью и базой данных"),
    UI_UX("Material 3 UI/UX Engineer", "Jetpack Compose / Material You компоненты, пружинные анимации, адаптивная верстка"),
    QA_TESTING("QA & Verification Specialist", "Unit/Integration тесты, граничные случаи, проверка устойчивости к сбоям"),
    SECURITY("Security & Crypto Auditor", "Аудит безопасности, защита ключей, предотвращение инъекций и утечек памяти"),
    REFACTORING("Performance & Refactoring Lead", "Оптимизация аллокаций, чистота кода, устранение дублирования и типизация")
}

@Serializable
data class AgentParticipant(
    val agentId: String,
    val displayName: String,
    val role: SubAgentSpecialty,
    val modelSpec: AiModelSpec,
    val effortConfig: CombinedEffortConfig = CombinedEffortConfig()
)

@Serializable
enum class AgentNodeStatus {
    IDLE,
    THINKING,
    WRITING_FILE,
    RUNNING_TERMINAL,
    HEALING_ERROR,
    COMPLETED,
    FAILED
}

@Serializable
data class AgentGraphNode(
    val agentId: String,
    val name: String,
    val role: SubAgentSpecialty,
    val modelName: String,
    val status: AgentNodeStatus,
    val activeTarget: String? = null,
    val parentAgentId: String? = null
)

@Serializable
data class TokenTelemetry(
    val providerId: String,
    val modelId: String,
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    val tokensPerSecond: Double = 0.0,
    val estimatedCostUsd: Double = 0.0
)

@Serializable
data class FsSnapshot(
    val snapshotId: String,
    val label: String,
    val createdAtEpochMs: Long,
    val agentId: String,
    val filesHash: String,
    val fileArchivePath: String
)

@Serializable
data class LivePreviewPayload(
    val type: PreviewContentType,
    val title: String,
    val rawContent: String,
    val entryFilePath: String? = null
)

@Serializable
enum class PreviewContentType {
    HTML_WEB,
    MARKDOWN,
    SVG_VECTOR,
    COMPOSE_LAYOUT_SUMMARY
}
