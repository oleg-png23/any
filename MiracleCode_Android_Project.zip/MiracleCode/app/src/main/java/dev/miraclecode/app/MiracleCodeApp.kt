package dev.miraclecode.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MiracleCodeApp : Application()
