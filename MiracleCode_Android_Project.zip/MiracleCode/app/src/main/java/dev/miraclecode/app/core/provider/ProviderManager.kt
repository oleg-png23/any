package dev.miraclecode.app.core.provider

import dev.miraclecode.app.data.local.AiModelEntity
import dev.miraclecode.app.data.local.EncryptedKeyVault
import dev.miraclecode.app.data.local.MiracleDao
import dev.miraclecode.app.data.local.ProviderEntity
import dev.miraclecode.app.domain.model.AiModelSpec
import dev.miraclecode.app.domain.model.ApiCompatibilityType
import dev.miraclecode.app.domain.model.PresetProviders
import dev.miraclecode.app.domain.model.ProviderConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProviderManager @Inject constructor(
    private val miracleDao: MiracleDao,
    private val keyVault: EncryptedKeyVault,
    private val okHttpClient: OkHttpClient,
    private val json: Json
) {
    suspend fun ensurePresetsSeeded() = withContext(Dispatchers.IO) {
        val entities = PresetProviders.ALL.map { it.toEntity() }
        miracleDao.upsertProviders(entities)
    }

    fun observeProviders(): Flow<List<ProviderConfig>> =
        miracleDao.observeProviders().map { list -> list.map { it.toDomain() } }

    fun searchModels(query: String): Flow<List<AiModelSpec>> =
        miracleDao.searchModels(query).map { list -> list.map { it.toDomain() } }

    suspend fun addCustomProviderAndFetchModels(
        name: String,
        baseUrl: String,
        apiKey: String,
        compatibilityType: ApiCompatibilityType,
        customHeaders: Map<String, String>
    ): Result<List<AiModelSpec>> = withContext(Dispatchers.IO) {
        val cleanId = "custom_${name.lowercase().replace(Regex("[^a-z0-9]"), "_")}_${UUID.randomUUID().toString().take(6)}"
        val config = ProviderConfig(
            id = cleanId,
            name = name.trim(),
            baseUrl = baseUrl.trimEnd('/'),
            modelsEndpoint = when (compatibilityType) {
                ApiCompatibilityType.GOOGLE_GEMINI -> "/v1beta/models"
                ApiCompatibilityType.OLLAMA_NATIVE -> "/api/tags"
                else -> "/v1/models"
            },
            chatEndpoint = when (compatibilityType) {
                ApiCompatibilityType.ANTHROPIC_MESSAGES -> "/v1/messages"
                ApiCompatibilityType.GOOGLE_GEMINI -> "/v1beta/openai/chat/completions"
                else -> "/v1/chat/completions"
            },
            compatibilityType = compatibilityType,
            customHeaders = customHeaders,
            isPreset = false,
            isEnabled = true
        )
        miracleDao.upsertProvider(config.toEntity())
        if (apiKey.isNotBlank()) {
            keyVault.saveApiKey(cleanId, apiKey)
        }
        fetchModelsFromProvider(config)
    }

    suspend fun setApiKeyAndAutoFetch(
        provider: ProviderConfig,
        apiKey: String
    ): Result<List<AiModelSpec>> = withContext(Dispatchers.IO) {
        keyVault.saveApiKey(provider.id, apiKey)
        fetchModelsFromProvider(provider)
    }

    suspend fun fetchModelsFromProvider(provider: ProviderConfig): Result<List<AiModelSpec>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val apiKey = keyVault.getApiKey(provider.id)
                val url = buildModelsUrl(provider, apiKey)

                val requestBuilder = Request.Builder().url(url).get()
                when (provider.compatibilityType) {
                    ApiCompatibilityType.ANTHROPIC_MESSAGES -> {
                        if (!apiKey.isNullOrBlank()) {
                            requestBuilder.header("x-api-key", apiKey)
                        }
                        requestBuilder.header("anthropic-version", "2023-06-01")
                    }
                    ApiCompatibilityType.GOOGLE_GEMINI -> {
                        if (!apiKey.isNullOrBlank()) {
                            requestBuilder.header("x-goog-api-key", apiKey)
                        }
                    }
                    else -> {
                        if (!apiKey.isNullOrBlank()) {
                            requestBuilder.header("Authorization", "Bearer $apiKey")
                        }
                    }
                }
                provider.customHeaders.forEach { (k, v) ->
                    requestBuilder.header(k, v)
                }

                val responseBody = okHttpClient.newCall(requestBuilder.build()).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IllegalStateException("HTTP ${response.code}: не удалось загрузить модели от ${provider.name}")
                    }
                    response.body?.string() ?: "{}"
                }

                val parsedModels = parseModelsPayload(provider, responseBody)
                miracleDao.replaceModelsForProvider(parsedModels.map { it.toEntity() })
                miracleDao.upsertProvider(
                    provider.copy(lastSyncedEpochMs = System.currentTimeMillis()).toEntity()
                )
                parsedModels
            }
        }

    private fun buildModelsUrl(provider: ProviderConfig, apiKey: String?): String {
        val base = provider.baseUrl.trimEnd('/')
        val path = provider.modelsEndpoint
        return if (provider.compatibilityType == ApiCompatibilityType.GOOGLE_GEMINI && !apiKey.isNullOrBlank()) {
            "$base$path?key=$apiKey"
        } else {
            "$base$path"
        }
    }

    internal fun parseModelsPayload(provider: ProviderConfig, rawJson: String): List<AiModelSpec> {
        val root = json.parseToJsonElement(rawJson).jsonObject
        val array = when {
            "data" in root -> root["data"]?.jsonArray
            "models" in root -> root["models"]?.jsonArray
            else -> null
        } ?: return emptyList()

        return array.mapNotNull { element ->
            val obj = element.jsonObject
            val rawId = obj["id"]?.jsonPrimitive?.content
                ?: obj["name"]?.jsonPrimitive?.content
                ?: return@mapNotNull null

            val cleanId = rawId.removePrefix("models/")
            val displayName = obj["display_name"]?.jsonPrimitive?.content
                ?: obj["displayName"]?.jsonPrimitive?.content
                ?: cleanId

            val contextLen = obj["context_length"]?.jsonPrimitive?.intOrNull
                ?: obj["inputTokenLimit"]?.jsonPrimitive?.intOrNull
                ?: obj["max_model_len"]?.jsonPrimitive?.intOrNull
                ?: inferContextWindow(cleanId)

            val maxOutput = obj["outputTokenLimit"]?.jsonPrimitive?.intOrNull
                ?: obj["max_completion_tokens"]?.jsonPrimitive?.intOrNull
                ?: 8_192

            val lowerId = cleanId.lowercase()
            val supportsReasoning = obj["supports_reasoning"]?.jsonPrimitive?.booleanOrNull
                ?: (lowerId.contains("o1") || lowerId.contains("o3") || lowerId.contains("o4") ||
                    lowerId.contains("r1") || lowerId.contains("reasoner") ||
                    lowerId.contains("thinking") || lowerId.contains("claude-3-7") ||
                    lowerId.contains("claude-4") || lowerId.contains("gemini-2.5") ||
                    lowerId.contains("grok-3"))

            val supportsVision = lowerId.contains("vision") || lowerId.contains("4o") ||
                lowerId.contains("claude-3") || lowerId.contains("claude-4") ||
                lowerId.contains("gemini") || lowerId.contains("pixtral") || lowerId.contains("vl")

            val pricingObj = obj["pricing"] as? JsonObject
            val promptCost = pricingObj?.get("prompt")?.jsonPrimitive?.doubleOrNull?.times(1_000_000) ?: 0.0
            val completionCost = pricingObj?.get("completion")?.jsonPrimitive?.doubleOrNull?.times(1_000_000) ?: 0.0

            AiModelSpec(
                id = cleanId,
                providerId = provider.id,
                displayName = displayName,
                contextWindowTokens = contextLen,
                maxOutputTokens = maxOutput,
                supportsVision = supportsVision,
                supportsToolCalling = true,
                supportsNativeReasoning = supportsReasoning,
                inputCostPerMillionUsd = promptCost,
                outputCostPerMillionUsd = completionCost
            )
        }
    }

    private fun inferContextWindow(modelId: String): Int {
        val lower = modelId.lowercase()
        return when {
            lower.contains("gemini") -> 1_048_576
            lower.contains("claude") -> 200_000
            lower.contains("gpt-4") || lower.contains("o1") || lower.contains("o3") || lower.contains("deepseek") -> 128_000
            else -> 64_000
        }
    }

    private fun ProviderConfig.toEntity() = ProviderEntity(
        id = id,
        name = name,
        baseUrl = baseUrl,
        modelsEndpoint = modelsEndpoint,
        chatEndpoint = chatEndpoint,
        compatibilityType = compatibilityType.name,
        customHeadersJson = json.encodeToString(customHeaders),
        isPreset = isPreset,
        isEnabled = isEnabled,
        lastSyncedEpochMs = lastSyncedEpochMs
    )

    private fun ProviderEntity.toDomain() = ProviderConfig(
        id = id,
        name = name,
        baseUrl = baseUrl,
        modelsEndpoint = modelsEndpoint,
        chatEndpoint = chatEndpoint,
        compatibilityType = runCatching { ApiCompatibilityType.valueOf(compatibilityType) }
            .getOrDefault(ApiCompatibilityType.OPENAI_COMPATIBLE),
        customHeaders = runCatching { json.decodeFromString<Map<String, String>>(customHeadersJson) }
            .getOrDefault(emptyMap()),
        isPreset = isPreset,
        isEnabled = isEnabled,
        lastSyncedEpochMs = lastSyncedEpochMs
    )

    private fun AiModelSpec.toEntity() = AiModelEntity(
        id = id,
        providerId = providerId,
        displayName = displayName,
        contextWindowTokens = contextWindowTokens,
        maxOutputTokens = maxOutputTokens,
        supportsVision = supportsVision,
        supportsToolCalling = supportsToolCalling,
        supportsNativeReasoning = supportsNativeReasoning,
        inputCostPerMillionUsd = inputCostPerMillionUsd,
        outputCostPerMillionUsd = outputCostPerMillionUsd
    )

    private fun AiModelEntity.toDomain() = AiModelSpec(
        id = id,
        providerId = providerId,
        displayName = displayName,
        contextWindowTokens = contextWindowTokens,
        maxOutputTokens = maxOutputTokens,
        supportsVision = supportsVision,
        supportsToolCalling = supportsToolCalling,
        supportsNativeReasoning = supportsNativeReasoning,
        inputCostPerMillionUsd = inputCostPerMillionUsd,
        outputCostPerMillionUsd = outputCostPerMillionUsd
    )
}
