package dev.miraclecode.app.domain.model

import kotlinx.serialization.Serializable

/**
 * 4.1. Model Effort (Нативный уровень модели)
 * Управляет нативными параметрами рассуждения API: reasoning_effort, thinking budget tokens, temperature/top_p.
 */
@Serializable
enum class ModelEffortLevel(
    val label: String,
    val openAiReasoningEffort: String?,
    val thinkingBudgetTokens: Int,
    val defaultTemperature: Double,
    val defaultTopP: Double
) {
    LOW(
        label = "Low",
        openAiReasoningEffort = "low",
        thinkingBudgetTokens = 1024,
        defaultTemperature = 0.2,
        defaultTopP = 0.85
    ),
    MEDIUM(
        label = "Medium",
        openAiReasoningEffort = "medium",
        thinkingBudgetTokens = 4096,
        defaultTemperature = 0.4,
        defaultTopP = 0.9
    ),
    HIGH(
        label = "High",
        openAiReasoningEffort = "high",
        thinkingBudgetTokens = 16384,
        defaultTemperature = 0.6,
        defaultTopP = 0.95
    ),
    MAX(
        label = "Max",
        openAiReasoningEffort = "high",
        thinkingBudgetTokens = 32768,
        defaultTemperature = 0.7,
        defaultTopP = 0.98
    ),
    CUSTOM_BUDGET(
        label = "Custom Budget",
        openAiReasoningEffort = "high",
        thinkingBudgetTokens = 8192,
        defaultTemperature = 0.5,
        defaultTopP = 0.95
    )
}

/**
 * 4.2. Layer Effort (Надстроечный промпт-уровень / Meta-Cognitive Layer)
 * Работает поверх любой модели (даже без нативного reasoning) через невидимую многослойную системную инъекцию.
 */
@Serializable
enum class LayerEffortLevel(val title: String, val badge: String) {
    OFF("Off", "L0"),
    LAYER_1_STRUCTURED("Layer 1: Structured", "L1"),
    LAYER_2_DEEP_CRITIQUE("Layer 2: Deep Critique", "L2"),
    LAYER_3_GODLIKE_EXHAUSTIVE("Layer 3: Godlike Exhaustive", "L3")
}

@Serializable
data class CombinedEffortConfig(
    val modelEffort: ModelEffortLevel = ModelEffortLevel.MEDIUM,
    val customThinkingBudgetTokens: Int = 12_288,
    val layerEffort: LayerEffortLevel = LayerEffortLevel.LAYER_1_STRUCTURED
)
