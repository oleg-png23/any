package dev.miraclecode.app.di

import android.content.Context
import androidx.room.Room
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dev.miraclecode.app.core.orchestration.LlmGateway
import dev.miraclecode.app.data.local.MiracleDao
import dev.miraclecode.app.data.local.MiracleDatabase
import dev.miraclecode.app.data.remote.OkHttpLlmGateway
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MiracleDatabase =
        Room.databaseBuilder(
            context,
            MiracleDatabase::class.java,
            "miracle_code.db"
        ).fallbackToDestructiveMigration().build()

    @Provides
    fun provideMiracleDao(db: MiracleDatabase): MiracleDao = db.miracleDao()

    @Provides
    @Singleton
    fun provideLlmGateway(impl: OkHttpLlmGateway): LlmGateway = impl
}
