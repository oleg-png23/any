package dev.miraclecode.app.data.remote

import dev.miraclecode.app.core.orchestration.LlmGateway
import dev.miraclecode.app.data.local.EncryptedKeyVault
import dev.miraclecode.app.domain.model.AgentParticipant
import dev.miraclecode.app.domain.model.ApiCompatibilityType
import dev.miraclecode.app.domain.model.PresetProviders
import dev.miraclecode.app.domain.model.TokenTelemetry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OkHttpLlmGateway @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val keyVault: EncryptedKeyVault,
    private val json: Json
) : LlmGateway {

    override suspend fun complete(
        agent: AgentParticipant,
        systemPrompt: String,
        userPrompt: String,
        compatibilityType: ApiCompatibilityType
    ): Pair<String, TokenTelemetry> = withContext(Dispatchers.IO) {
        val startMs = System.currentTimeMillis()
        val provider = PresetProviders.ALL.find { it.id == agent.modelSpec.providerId }
            ?: PresetProviders.ALL.first()
        val apiKey = keyVault.getApiKey(provider.id)

        if (apiKey.isNullOrBlank() && provider.compatibilityType != ApiCompatibilityType.OLLAMA_NATIVE) {
            val simulated = buildSimulatedResponse(agent, userPrompt)
            val elapsedSec = ((System.currentTimeMillis() - startMs).coerceAtLeast(120L)) / 1000.0
            val outTokens = (simulated.length / 4).coerceAtLeast(64)
            return@withContext simulated to TokenTelemetry(
                providerId = provider.id,
                modelId = agent.modelSpec.id,
                promptTokens = (systemPrompt.length + userPrompt.length) / 4,
                completionTokens = outTokens,
                tokensPerSecond = outTokens / elapsedSec,
                estimatedCostUsd = 0.0018
            )
        }

        val payload = buildJsonObject {
            put("model", agent.modelSpec.id)
            put("messages", buildJsonArray {
                add(buildJsonObject {
                    put("role", "system")
                    put("content", systemPrompt)
                })
                add(buildJsonObject {
                    put("role", "user")
                    put("content", userPrompt)
                })
            })
        }

        val url = "${provider.baseUrl.trimEnd('/')}${provider.chatEndpoint}"
        val reqBuilder = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody("application/json".toMediaType()))

        if (!apiKey.isNullOrBlank()) {
            reqBuilder.header("Authorization", "Bearer $apiKey")
        }
        provider.customHeaders.forEach { (k, v) -> reqBuilder.header(k, v) }

        okHttpClient.newCall(reqBuilder.build()).execute().use { response ->
            val raw = response.body?.string() ?: "{}"
            val root = json.parseToJsonElement(raw).jsonObject
            val content = root["choices"]?.jsonArray?.firstOrNull()
                ?.jsonObject?.get("message")?.jsonObject?.get("content")?.jsonPrimitive?.content
                ?: raw

            val usage = root["usage"]?.jsonObject
            val pTokens = usage?.get("prompt_tokens")?.jsonPrimitive?.intOrNull ?: 256
            val cTokens = usage?.get("completion_tokens")?.jsonPrimitive?.intOrNull ?: 512
            val elapsedSec = ((System.currentTimeMillis() - startMs).coerceAtLeast(100L)) / 1000.0
            val cost = (pTokens * agent.modelSpec.inputCostPerMillionUsd +
                cTokens * agent.modelSpec.outputCostPerMillionUsd) / 1_000_000.0

            content to TokenTelemetry(
                providerId = provider.id,
                modelId = agent.modelSpec.id,
                promptTokens = pTokens,
                completionTokens = cTokens,
                tokensPerSecond = cTokens / elapsedSec,
                estimatedCostUsd = cost
            )
        }
    }

    private fun buildSimulatedResponse(agent: AgentParticipant, userPrompt: String): String = """
        ### [${agent.displayName} • ${agent.role.roleTitle}]
        Задача обработана моделью `${agent.modelSpec.displayName}` (Model Effort: `${agent.effortConfig.modelEffort.label}`, Layer Effort: `${agent.effortConfig.layerEffort.badge}`).
        
        - Спроектирована модульная архитектура под запрос: *${userPrompt.take(90)}*
        - Создана точка входа в скрытой песочнице `src/MainSolution.kt`
        
        ```html
        <div style="font-family:sans-serif;padding:16px;background:#111318;color:#E2E2E9;border-radius:16px;">
          <h3 style="margin-top:0;color:#AAC7FF;">Miracle Live Preview</h3>
          <p>Сгенерировано агентом <b>${agent.displayName}</b> (${agent.modelSpec.displayName}).</p>
        </div>
        ```
    """.trimIndent()
}
