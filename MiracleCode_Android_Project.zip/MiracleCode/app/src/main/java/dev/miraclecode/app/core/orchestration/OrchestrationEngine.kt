package dev.miraclecode.app.core.orchestration

import dev.miraclecode.app.core.effort.EffortEngine
import dev.miraclecode.app.core.sandbox.HiddenSandboxBridge
import dev.miraclecode.app.domain.model.AgentGraphNode
import dev.miraclecode.app.domain.model.AgentNodeStatus
import dev.miraclecode.app.domain.model.AgentParticipant
import dev.miraclecode.app.domain.model.ApiCompatibilityType
import dev.miraclecode.app.domain.model.ExecutionMode
import dev.miraclecode.app.domain.model.LivePreviewPayload
import dev.miraclecode.app.domain.model.PreviewContentType
import dev.miraclecode.app.domain.model.SubAgentSpecialty
import dev.miraclecode.app.domain.model.TokenTelemetry
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

data class SideBySideCandidate(
    val agent: AgentParticipant,
    val responseText: String,
    val telemetry: TokenTelemetry
)

data class OrchestrationResult(
    val mode: ExecutionMode,
    val primaryOutput: String,
    val sideBySideCandidates: List<SideBySideCandidate> = emptyList(),
    val debateTranscript: List<Pair<String, String>> = emptyList(),
    val isolatedSubAgentOutputs: Map<SubAgentSpecialty, String> = emptyMap(),
    val autoHealIterationsUsed: Int = 0,
    val livePreview: LivePreviewPayload? = null,
    val telemetryList: List<TokenTelemetry> = emptyList()
)

interface LlmGateway {
    suspend fun complete(
        agent: AgentParticipant,
        systemPrompt: String,
        userPrompt: String,
        compatibilityType: ApiCompatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE
    ): Pair<String, TokenTelemetry>
}

@Singleton
class OrchestrationEngine @Inject constructor(
    private val effortEngine: EffortEngine,
    private val sandboxBridge: HiddenSandboxBridge,
    private val llmGateway: LlmGateway
) {
    private val _agentGraphNodes = MutableStateFlow<List<AgentGraphNode>>(emptyList())
    val agentGraphNodes: StateFlow<List<AgentGraphNode>> = _agentGraphNodes.asStateFlow()

    suspend fun runSoloMode(
        sessionId: String,
        agent: AgentParticipant,
        userPrompt: String
    ): OrchestrationResult {
        updateGraph(
            listOf(
                AgentGraphNode(
                    agentId = agent.agentId,
                    name = agent.displayName,
                    role = agent.role,
                    modelName = agent.modelSpec.displayName,
                    status = AgentNodeStatus.THINKING
                )
            )
        )

        val prepared = effortEngine.buildInferenceParameters(
            baseRoleSystemPrompt = agent.role.systemFocus,
            model = agent.modelSpec,
            compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE,
            effortConfig = agent.effortConfig
        )

        val (output, telemetry) = llmGateway.complete(
            agent = agent,
            systemPrompt = prepared.effectiveSystemPrompt,
            userPrompt = userPrompt
        )

        val preview = extractLivePreviewIfPresent(output)
        updateNodeStatus(agent.agentId, AgentNodeStatus.COMPLETED)

        return OrchestrationResult(
            mode = ExecutionMode.SOLO,
            primaryOutput = output,
            livePreview = preview,
            telemetryList = listOf(telemetry)
        )
    }

    suspend fun runSideBySideMode(
        agents: List<AgentParticipant>,
        userPrompt: String
    ): OrchestrationResult = coroutineScope {
        require(agents.size >= 2) { "Для режима Side-by-Side требуется минимум 2 модели" }

        updateGraph(
            agents.map {
                AgentGraphNode(
                    agentId = it.agentId,
                    name = it.displayName,
                    role = it.role,
                    modelName = it.modelSpec.displayName,
                    status = AgentNodeStatus.THINKING
                )
            }
        )

        val candidates = agents.map { agent ->
            async {
                val prepared = effortEngine.buildInferenceParameters(
                    baseRoleSystemPrompt = agent.role.systemFocus,
                    model = agent.modelSpec,
                    compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE,
                    effortConfig = agent.effortConfig
                )
                val (reply, telemetry) = llmGateway.complete(
                    agent = agent,
                    systemPrompt = prepared.effectiveSystemPrompt,
                    userPrompt = userPrompt
                )
                updateNodeStatus(agent.agentId, AgentNodeStatus.COMPLETED)
                SideBySideCandidate(
                    agent = agent,
                    responseText = reply,
                    telemetry = telemetry
                )
            }
        }.awaitAll()

        OrchestrationResult(
            mode = ExecutionMode.SIDE_BY_SIDE,
            primaryOutput = candidates.first().responseText,
            sideBySideCandidates = candidates,
            livePreview = extractLivePreviewIfPresent(candidates.first().responseText),
            telemetryList = candidates.map { it.telemetry }
        )
    }

    suspend fun runAgentMixMode(
        agents: List<AgentParticipant>,
        userPrompt: String,
        rounds: Int = 2
    ): OrchestrationResult {
        require(agents.size >= 2) { "Для Agent Mix требуется минимум 2 агента" }

        updateGraph(
            agents.map {
                AgentGraphNode(
                    agentId = it.agentId,
                    name = it.displayName,
                    role = it.role,
                    modelName = it.modelSpec.displayName,
                    status = AgentNodeStatus.IDLE
                )
            }
        )

        val sharedContextLog = StringBuilder("ИСХОДНАЯ ЗАДАЧА ПОЛЬЗОВАТЕЛЯ:\n$userPrompt\n\n")
        val transcript = mutableListOf<Pair<String, String>>()
        val telemetries = mutableListOf<TokenTelemetry>()

        for (round in 1..rounds) {
            for (agent in agents) {
                updateNodeStatus(agent.agentId, AgentNodeStatus.THINKING, "Раунд коллаборации #$round")
                val mixBasePrompt = """
                    Ты — участник режима Agent Mix (${agent.displayName}, роль: ${agent.role.roleTitle}).
                    Все агенты находятся в ЕДИНОМ ОБЩЕМ КОНТЕКСТЕ.
                    Критически оцени предложения предыдущих коллег, найди ошибки в их коде, предложи улучшения и приблизь команду к финальному решению.
                """.trimIndent()

                val prepared = effortEngine.buildInferenceParameters(
                    baseRoleSystemPrompt = mixBasePrompt,
                    model = agent.modelSpec,
                    compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE,
                    effortConfig = agent.effortConfig
                )

                val (reply, telemetry) = llmGateway.complete(
                    agent = agent,
                    systemPrompt = prepared.effectiveSystemPrompt,
                    userPrompt = sharedContextLog.toString()
                )

                sharedContextLog.append("--- [${agent.displayName} (${agent.role.roleTitle}), Раунд $round] ---\n$reply\n\n")
                transcript.add("${agent.displayName} (${agent.role.roleTitle})" to reply)
                telemetries.add(telemetry)
                updateNodeStatus(agent.agentId, AgentNodeStatus.COMPLETED)
            }
        }

        val finalConsensus = transcript.last().second
        return OrchestrationResult(
            mode = ExecutionMode.AGENT_MIX,
            primaryOutput = finalConsensus,
            debateTranscript = transcript,
            livePreview = extractLivePreviewIfPresent(finalConsensus),
            telemetryList = telemetries
        )
    }

    suspend fun runOrchestraMode(
        leadArchitect: AgentParticipant,
        subAgents: List<AgentParticipant>,
        userPrompt: String
    ): OrchestrationResult = coroutineScope {
        require(subAgents.size in 3..5) {
            "В режиме Orchestra должно быть строго от 3 до 5 изолированных субагентов (передано: ${subAgents.size})"
        }

        val initialNodes = buildList {
            add(
                AgentGraphNode(
                    agentId = leadArchitect.agentId,
                    name = leadArchitect.displayName,
                    role = SubAgentSpecialty.ORCHESTRATOR,
                    modelName = leadArchitect.modelSpec.displayName,
                    status = AgentNodeStatus.THINKING,
                    activeTarget = "Декомпозиция архитектуры и выдача изолированных ТЗ"
                )
            )
            subAgents.forEach { sub ->
                add(
                    AgentGraphNode(
                        agentId = sub.agentId,
                        name = sub.displayName,
                        role = sub.role,
                        modelName = sub.modelSpec.displayName,
                        status = AgentNodeStatus.IDLE,
                        parentAgentId = leadArchitect.agentId
                    )
                )
            }
        }
        updateGraph(initialNodes)

        val telemetries = mutableListOf<TokenTelemetry>()

        val decompositionPrompt = """
            Ты — Главный Архитектор (Orchestrator) в режиме Orchestra Mode.
            У тебя в подчинении ${subAgents.size} строго изолированных субагентов:
            ${subAgents.joinToString("\n") { "- ${it.role.name}: ${it.role.roleTitle} (${it.role.systemFocus})" }}
            Субагенты НЕ видят работу друг друга. Сформируй точные контракты интерфейсов и отдельное ТЗ для каждого субагента.
            Задача пользователя:
            $userPrompt
        """.trimIndent()

        val leadPrepared = effortEngine.buildInferenceParameters(
            baseRoleSystemPrompt = leadArchitect.role.systemFocus,
            model = leadArchitect.modelSpec,
            compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE,
            effortConfig = leadArchitect.effortConfig
        )
        val (architectSpec, decompTelemetry) = llmGateway.complete(
            agent = leadArchitect,
            systemPrompt = leadPrepared.effectiveSystemPrompt,
            userPrompt = decompositionPrompt
        )
        telemetries.add(decompTelemetry)

        val subAgentResults = subAgents.map { subAgent ->
            async {
                updateNodeStatus(
                    subAgent.agentId,
                    AgentNodeStatus.WRITING_FILE,
                    "Изолированная разработка модуля ${subAgent.role.roleTitle}"
                )
                val isolatedUserPrompt = """
                    [STRICT ISOLATION CONTEXT — SUBAGENT: ${subAgent.role.roleTitle}]
                    Ты работаешь в полной изоляции от других субагентов. Строго соблюдай контракты Главного Архитектора:
                    $architectSpec
                    
                    Реализуй ТОЛЬКО свою зону ответственности (${subAgent.role.roleTitle} — ${subAgent.role.systemFocus}).
                """.trimIndent()

                val subPrepared = effortEngine.buildInferenceParameters(
                    baseRoleSystemPrompt = subAgent.role.systemFocus,
                    model = subAgent.modelSpec,
                    compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE,
                    effortConfig = subAgent.effortConfig
                )
                val (subOutput, subTelemetry) = llmGateway.complete(
                    agent = subAgent,
                    systemPrompt = subPrepared.effectiveSystemPrompt,
                    userPrompt = isolatedUserPrompt
                )
                updateNodeStatus(subAgent.agentId, AgentNodeStatus.COMPLETED)
                Triple(subAgent.role, subOutput, subTelemetry)
            }
        }.awaitAll()

        subAgentResults.forEach { telemetries.add(it.third) }
        val isolatedMap = subAgentResults.associate { it.first to it.second }

        updateNodeStatus(
            leadArchitect.agentId,
            AgentNodeStatus.THINKING,
            "Разрешение конфликтов и финальная сборка проекта"
        )
        val synthesisInput = buildString {
            append("Исходная задача: $userPrompt\n\n")
            append("Архитектурный план:\n$architectSpec\n\n")
            subAgentResults.forEach { (role, code, _) ->
                append("=== ОТЧЕТ ИЗОЛИРОВАННОГО СУБАГЕНТА [${role.roleTitle}] ===\n$code\n\n")
            }
            append("Объедини все модули субагентов, устрани нестыковки импортов/интерфейсов и выдай целостный готовый проект.")
        }

        val (finalIntegratedProject, synthTelemetry) = llmGateway.complete(
            agent = leadArchitect,
            systemPrompt = leadPrepared.effectiveSystemPrompt,
            userPrompt = synthesisInput
        )
        telemetries.add(synthTelemetry)
        updateNodeStatus(leadArchitect.agentId, AgentNodeStatus.COMPLETED)

        OrchestrationResult(
            mode = ExecutionMode.ORCHESTRA,
            primaryOutput = finalIntegratedProject,
            isolatedSubAgentOutputs = isolatedMap,
            livePreview = extractLivePreviewIfPresent(finalIntegratedProject),
            telemetryList = telemetries
        )
    }

    suspend fun runAutonomousAgentMode(
        sessionId: String,
        autonomousAgent: AgentParticipant,
        subAgentPool: List<AgentParticipant>,
        userPrompt: String,
        verificationCommand: String = "sh ./verify_build.sh",
        maxAutoHealIterations: Int = 4
    ): OrchestrationResult {
        val telemetries = mutableListOf<TokenTelemetry>()
        val requiresOrchestra = userPrompt.length > 220 ||
            userPrompt.contains("архитектур", ignoreCase = true) ||
            userPrompt.contains("fullstack", ignoreCase = true) ||
            userPrompt.contains("мульти", ignoreCase = true)

        val initialResult = if (requiresOrchestra && subAgentPool.size >= 3) {
            runOrchestraMode(
                leadArchitect = autonomousAgent,
                subAgents = subAgentPool.take(4),
                userPrompt = userPrompt
            )
        } else {
            runSoloMode(
                sessionId = sessionId,
                agent = autonomousAgent,
                userPrompt = userPrompt
            )
        }
        telemetries.addAll(initialResult.telemetryList)

        var currentCode = initialResult.primaryOutput
        sandboxBridge.writeFileWithSnapshot(
            sessionId = sessionId,
            agentId = autonomousAgent.agentId,
            relativePath = "src/MainSolution.kt",
            content = currentCode
        )

        var healIteration = 0
        while (healIteration < maxAutoHealIterations) {
            updateNodeStatus(
                autonomousAgent.agentId,
                AgentNodeStatus.RUNNING_TERMINAL,
                verificationCommand
            )
            val cmdResult = sandboxBridge.executeCommand(
                agentId = autonomousAgent.agentId,
                command = verificationCommand
            )

            if (cmdResult.isSuccess || cmdResult.stderr.isBlank()) {
                updateNodeStatus(autonomousAgent.agentId, AgentNodeStatus.COMPLETED, "Build Verified (Exit 0)")
                break
            }

            healIteration++
            updateNodeStatus(
                autonomousAgent.agentId,
                AgentNodeStatus.HEALING_ERROR,
                "Auto-Heal #$healIteration: исправление ошибки из stderr"
            )

            val healPrompt = """
                [AUTO-HEAL LOOP — ITERATION #$healIteration / $maxAutoHealIterations]
                Команда в скрытом терминале завершилась с ошибкой (exitCode=${cmdResult.exitCode}):
                Команда: $verificationCommand
                STDERR:
                ${cmdResult.stderr}
                
                Текущий код:
                $currentCode
                
                Проанализируй стектрейс ошибки из stderr и выдай полностью исправленный рабочий код.
            """.trimIndent()

            val prepared = effortEngine.buildInferenceParameters(
                baseRoleSystemPrompt = autonomousAgent.role.systemFocus,
                model = autonomousAgent.modelSpec,
                compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE,
                effortConfig = autonomousAgent.effortConfig
            )

            val (healedCode, healTelemetry) = llmGateway.complete(
                agent = autonomousAgent,
                systemPrompt = prepared.effectiveSystemPrompt,
                userPrompt = healPrompt
            )
            telemetries.add(healTelemetry)
            currentCode = healedCode

            sandboxBridge.writeFileWithSnapshot(
                sessionId = sessionId,
                agentId = autonomousAgent.agentId,
                relativePath = "src/MainSolution.kt",
                content = currentCode
            )
        }

        return initialResult.copy(
            mode = ExecutionMode.AUTONOMOUS_AGENT,
            primaryOutput = currentCode,
            autoHealIterationsUsed = healIteration,
            livePreview = extractLivePreviewIfPresent(currentCode),
            telemetryList = telemetries
        )
    }

    fun extractLivePreviewIfPresent(content: String): LivePreviewPayload? {
        val htmlRegex = Regex("```html\\s*([\\s\\S]*?)```", RegexOption.IGNORE_CASE)
        htmlRegex.find(content)?.groupValues?.getOrNull(1)?.let { html ->
            return LivePreviewPayload(
                type = PreviewContentType.HTML_WEB,
                title = "Interactive Web / UI Preview",
                rawContent = html.trim()
            )
        }

        val svgRegex = Regex("```(?:svg|xml)\\s*(<svg[\\s\\S]*?</svg>)\\s*```", RegexOption.IGNORE_CASE)
        svgRegex.find(content)?.groupValues?.getOrNull(1)?.let { svg ->
            return LivePreviewPayload(
                type = PreviewContentType.SVG_VECTOR,
                title = "SVG Vector Preview",
                rawContent = svg.trim()
            )
        }

        return null
    }

    private fun updateGraph(nodes: List<AgentGraphNode>) {
        _agentGraphNodes.value = nodes
    }

    private fun updateNodeStatus(agentId: String, status: AgentNodeStatus, activeTarget: String? = null) {
        _agentGraphNodes.value = _agentGraphNodes.value.map { node ->
            if (node.agentId == agentId) {
                node.copy(status = status, activeTarget = activeTarget)
            } else {
                node
            }
        }
    }
}
