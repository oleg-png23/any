package dev.miraclecode.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import dev.miraclecode.app.domain.model.ExecutionMode
import dev.miraclecode.app.domain.model.LayerEffortLevel
import dev.miraclecode.app.domain.model.ModelEffortLevel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "miracle_settings")

enum class ThemeMode {
    SYSTEM, LIGHT, DARK, AMOLED_BLACK
}

data class MiracleUserSettings(
    val themeMode: ThemeMode = ThemeMode.AMOLED_BLACK,
    val dynamicColorEnabled: Boolean = true,
    val showInternalEditorAndTerminal: Boolean = false,
    val activeExecutionMode: ExecutionMode = ExecutionMode.SOLO,
    val activeModelEffort: ModelEffortLevel = ModelEffortLevel.MEDIUM,
    val customThinkingBudgetTokens: Int = 12_288,
    val activeLayerEffort: LayerEffortLevel = LayerEffortLevel.LAYER_1_STRUCTURED,
    val autoHealMaxIterations: Int = 4
)

@Singleton
class UserPreferencesDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val SHOW_INTERNAL_EDITOR_TERMINAL = booleanPreferencesKey("dev_show_internal_editor_terminal")
        val EXECUTION_MODE = stringPreferencesKey("execution_mode")
        val MODEL_EFFORT = stringPreferencesKey("model_effort")
        val CUSTOM_THINKING_BUDGET = intPreferencesKey("custom_thinking_budget")
        val LAYER_EFFORT = stringPreferencesKey("layer_effort")
        val AUTO_HEAL_MAX_ITER = intPreferencesKey("auto_heal_max_iter")
    }

    val settingsFlow: Flow<MiracleUserSettings> = context.dataStore.data.map { prefs ->
        MiracleUserSettings(
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.AMOLED_BLACK,
            dynamicColorEnabled = prefs[Keys.DYNAMIC_COLOR] ?: true,
            showInternalEditorAndTerminal = prefs[Keys.SHOW_INTERNAL_EDITOR_TERMINAL] ?: false,
            activeExecutionMode = prefs[Keys.EXECUTION_MODE]?.let { runCatching { ExecutionMode.valueOf(it) }.getOrNull() }
                ?: ExecutionMode.SOLO,
            activeModelEffort = prefs[Keys.MODEL_EFFORT]?.let { runCatching { ModelEffortLevel.valueOf(it) }.getOrNull() }
                ?: ModelEffortLevel.MEDIUM,
            customThinkingBudgetTokens = prefs[Keys.CUSTOM_THINKING_BUDGET] ?: 12_288,
            activeLayerEffort = prefs[Keys.LAYER_EFFORT]?.let { runCatching { LayerEffortLevel.valueOf(it) }.getOrNull() }
                ?: LayerEffortLevel.LAYER_1_STRUCTURED,
            autoHealMaxIterations = prefs[Keys.AUTO_HEAL_MAX_ITER] ?: 4
        )
    }

    suspend fun setShowInternalEditorAndTerminal(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_INTERNAL_EDITOR_TERMINAL] = enabled }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDynamicColor(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DYNAMIC_COLOR] = enabled }
    }

    suspend fun setExecutionMode(mode: ExecutionMode) {
        context.dataStore.edit { it[Keys.EXECUTION_MODE] = mode.name }
    }

    suspend fun setModelEffort(level: ModelEffortLevel, customBudget: Int? = null) {
        context.dataStore.edit {
            it[Keys.MODEL_EFFORT] = level.name
            if (customBudget != null) {
                it[Keys.CUSTOM_THINKING_BUDGET] = customBudget
            }
        }
    }

    suspend fun setLayerEffort(level: LayerEffortLevel) {
        context.dataStore.edit { it[Keys.LAYER_EFFORT] = level.name }
    }
}
