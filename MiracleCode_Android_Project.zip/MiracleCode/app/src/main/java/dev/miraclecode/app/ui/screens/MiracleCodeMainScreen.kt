package dev.miraclecode.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.miraclecode.app.data.local.ThemeMode
import dev.miraclecode.app.domain.model.AgentGraphNode
import dev.miraclecode.app.domain.model.ApiCompatibilityType
import dev.miraclecode.app.domain.model.ExecutionMode
import dev.miraclecode.app.domain.model.LayerEffortLevel
import dev.miraclecode.app.domain.model.ModelEffortLevel
import dev.miraclecode.app.ui.viewmodel.MiracleMainViewModel
import dev.miraclecode.app.ui.viewmodel.MiracleUiState

private enum class TopLevelTab {
    COMMAND_CENTER,
    PROVIDERS,
    HIDDEN_EDITOR_TERMINAL,
    SETTINGS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MiracleCodeMainScreen(
    uiState: MiracleUiState,
    viewModel: MiracleMainViewModel
) {
    var activeTab by rememberSaveable { mutableStateOf(TopLevelTab.COMMAND_CENTER) }

    if (!uiState.settings.showInternalEditorAndTerminal && activeTab == TopLevelTab.HIDDEN_EDITOR_TERMINAL) {
        activeTab = TopLevelTab.COMMAND_CENTER
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Miracle Code",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${uiState.settings.activeExecutionMode.title} • Model: ${uiState.settings.activeModelEffort.label} • ${uiState.settings.activeLayerEffort.badge}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = activeTab == TopLevelTab.COMMAND_CENTER,
                    onClick = { activeTab = TopLevelTab.COMMAND_CENTER },
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null) },
                    label = { Text("Центр ИИ") }
                )
                NavigationBarItem(
                    selected = activeTab == TopLevelTab.PROVIDERS,
                    onClick = { activeTab = TopLevelTab.PROVIDERS },
                    icon = { Icon(Icons.Default.Hub, contentDescription = null) },
                    label = { Text("Провайдеры") }
                )
                if (uiState.settings.showInternalEditorAndTerminal) {
                    NavigationBarItem(
                        selected = activeTab == TopLevelTab.HIDDEN_EDITOR_TERMINAL,
                        onClick = { activeTab = TopLevelTab.HIDDEN_EDITOR_TERMINAL },
                        icon = { Icon(Icons.Default.Terminal, contentDescription = null) },
                        label = { Text("IDE & Sandbox") }
                    )
                }
                NavigationBarItem(
                    selected = activeTab == TopLevelTab.SETTINGS,
                    onClick = { activeTab = TopLevelTab.SETTINGS },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("Настройки") }
                )
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = activeTab,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            label = "MiracleSpringTabTransition"
        ) { tab ->
            when (tab) {
                TopLevelTab.COMMAND_CENTER -> CommandCenterTab(uiState, viewModel)
                TopLevelTab.PROVIDERS -> ProvidersAndModelsTab(uiState, viewModel)
                TopLevelTab.HIDDEN_EDITOR_TERMINAL -> HiddenEditorAndTerminalTab(uiState, viewModel)
                TopLevelTab.SETTINGS -> AdvancedSettingsTab(uiState, viewModel)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CommandCenterTab(
    uiState: MiracleUiState,
    viewModel: MiracleMainViewModel
) {
    var promptText by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AnimatedVisibility(
            visible = uiState.activeGraphNodes.isNotEmpty(),
            enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) + slideInVertically(),
            exit = fadeOut()
        ) {
            VisualAgentGraphCard(nodes = uiState.activeGraphNodes)
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            uiState.lastOrchestrationResult?.let { res ->
                if (res.mode == ExecutionMode.SIDE_BY_SIDE && res.sideBySideCandidates.isNotEmpty()) {
                    item {
                        Text(
                            text = "Side-by-Side Сравнение (${res.sideBySideCandidates.size} модели параллельно)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            itemsIndexed(res.sideBySideCandidates) { idx, candidate ->
                                val isWinner = uiState.selectedSideBySideWinnerIndex == idx
                                Card(
                                    modifier = Modifier.width(300.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isWinner)
                                            MaterialTheme.colorScheme.primaryContainer
                                        else
                                            MaterialTheme.colorScheme.surfaceVariant
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = candidate.agent.displayName,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = candidate.responseText,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        Button(
                                            onClick = { viewModel.selectSideBySideWinner(idx) },
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                                            Spacer(Modifier.width(6.dp))
                                            Text(
                                                if (isWinner) "Выбрано как основа"
                                                else "Выбрать лучший ответ как основу"
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Результат (${res.mode.title})",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                if (res.autoHealIterationsUsed > 0) {
                                    Text(
                                        text = "Auto-Heal Loop: автоматически исправлено ошибок терминала: ${res.autoHealIterationsUsed}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = res.primaryOutput,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }

                res.livePreview?.let { preview ->
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "Live Preview Engine • ${preview.title} (${preview.type.name})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = preview.rawContent,
                                    fontFamily = FontFamily.Monospace,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }

                if (res.telemetryList.isNotEmpty()) {
                    item {
                        val totalTokens = res.telemetryList.sumOf { it.promptTokens + it.completionTokens }
                        val avgSpeed = res.telemetryList.map { it.tokensPerSecond }.average()
                        val totalCost = res.telemetryList.sumOf { it.estimatedCostUsd }
                        AssistChip(
                            onClick = {},
                            label = {
                                Text(
                                    "Телеметрия: $totalTokens tok • ${"%.1f".format(avgSpeed)} tok/s • $${"%.4f".format(totalCost)}"
                                )
                            }
                        )
                    }
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExecutionMode.entries.forEach { mode ->
                    FilterChip(
                        selected = uiState.settings.activeExecutionMode == mode,
                        onClick = { viewModel.setExecutionMode(mode) },
                        label = { Text(mode.title) }
                    )
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ModelEffortLevel.entries.forEach { effort ->
                    FilterChip(
                        selected = uiState.settings.activeModelEffort == effort,
                        onClick = { viewModel.setModelEffort(effort) },
                        label = { Text("Model: ${effort.label}") }
                    )
                }
                LayerEffortLevel.entries.forEach { layer ->
                    FilterChip(
                        selected = uiState.settings.activeLayerEffort == layer,
                        onClick = { viewModel.setLayerEffort(layer) },
                        label = { Text(layer.title) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = promptText,
                    onValueChange = { promptText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Опишите задачу для агентов Miracle Code...") },
                    maxLines = 4
                )
                Button(
                    onClick = {
                        viewModel.executePrompt(promptText)
                        promptText = ""
                    },
                    enabled = !uiState.isBusy && promptText.isNotBlank()
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Run")
                }
            }
        }
    }
}

@Composable
private fun VisualAgentGraphCard(nodes: List<AgentGraphNode>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Visual Agent Graph (Active Orchestration Topology)",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            nodes.forEach { node ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${if (node.parentAgentId != null) "  └─ " else "★ "}${node.name} [${node.role.roleTitle}]",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "${node.status.name}${node.activeTarget?.let { " ($it)" } ?: ""}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun ProvidersAndModelsTab(
    uiState: MiracleUiState,
    viewModel: MiracleMainViewModel
) {
    var selectedProvider by remember { mutableStateOf(uiState.providers.firstOrNull()) }
    var apiKeyInput by remember { mutableStateOf("") }
    var customName by remember { mutableStateOf("") }
    var customBaseUrl by remember { mutableStateOf("https://") }
    var customHeaderKey by remember { mutableStateOf("") }
    var customHeaderVal by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Пресет-провайдеры и Автозагрузка Моделей (EncryptedSharedPreferences)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            uiState.statusBanner?.let { banner ->
                Text(
                    text = banner,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(uiState.providers) { _, provider ->
                    FilterChip(
                        selected = selectedProvider?.id == provider.id,
                        onClick = { selectedProvider = provider },
                        label = { Text(provider.name) }
                    )
                }
            }
        }

        selectedProvider?.let { provider ->
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "${provider.name} (${provider.baseUrl}${provider.modelsEndpoint})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedTextField(
                            value = apiKeyInput,
                            onValueChange = { apiKeyInput = it },
                            label = { Text("API Key (шифруется в Android Keystore)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                viewModel.saveApiKeyAndFetchModels(provider, apiKeyInput)
                                apiKeyInput = ""
                            }
                        ) {
                            Text("Сохранить ключ и загрузить список моделей (GET /v1/models)")
                        }
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Добавить Кастомный Провайдер (Custom Provider)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedTextField(
                        value = customName,
                        onValueChange = { customName = it },
                        label = { Text("Название провайдера") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = customBaseUrl,
                        onValueChange = { customBaseUrl = it },
                        label = { Text("Base URL (OpenAI / Anthropic compatible)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = customHeaderKey,
                            onValueChange = { customHeaderKey = it },
                            label = { Text("Header Key") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = customHeaderVal,
                            onValueChange = { customHeaderVal = it },
                            label = { Text("Header Value") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            val headers = if (customHeaderKey.isNotBlank()) {
                                mapOf(customHeaderKey to customHeaderVal)
                            } else emptyMap()
                            viewModel.addCustomProvider(
                                name = customName,
                                baseUrl = customBaseUrl,
                                apiKey = apiKeyInput,
                                compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE,
                                headers = headers
                            )
                            customName = ""
                        }
                    ) {
                        Text("Добавить провайдер и синхронизировать модели")
                    }
                }
            }
        }
    }
}

@Composable
private fun HiddenEditorAndTerminalTab(
    uiState: MiracleUiState,
    viewModel: MiracleMainViewModel
) {
    var manualCmd by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Внутренний Редактор Кода и Linux Sandbox (Разблокировано в Режиме разработчика)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Card(modifier = Modifier.weight(1f).fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Code, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = uiState.selectedEditorFilePath,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = uiState.selectedEditorFileContent.ifBlank { "// Файл будет создан ИИ-агентом в фоновом режиме" },
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Android Terminal / PRoot Sandbox Console",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                LazyColumn(modifier = Modifier.weight(1f)) {
                    itemsIndexed(uiState.terminalLogs) { _, line ->
                        Text(
                            text = line,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = manualCmd,
                        onValueChange = { manualCmd = it },
                        placeholder = { Text("sh / ./gradlew test ...") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            if (manualCmd.isNotBlank()) {
                                viewModel.runManualTerminalCommand(manualCmd)
                                manualCmd = ""
                            }
                        }
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null)
                    }
                }
            }
        }
    }
}

@Composable
private fun AdvancedSettingsTab(
    uiState: MiracleUiState,
    viewModel: MiracleMainViewModel
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Тема оформления (Material Design 3 / Material You)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.entries.forEach { mode ->
                FilterChip(
                    selected = uiState.settings.themeMode == mode,
                    onClick = { viewModel.setThemeMode(mode) },
                    label = { Text(mode.name) }
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Dynamic Color (адаптация под обои Android 12+)")
            Switch(
                checked = uiState.settings.dynamicColorEnabled,
                onCheckedChange = { viewModel.setDynamicColor(it) }
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Настройки → Расширенные → Режим разработчика",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "По умолчанию внутренний редактор кода и терминал скрыты ('Clean First') и управляются только ИИ-агентами в фоновом режиме.",
                    style = MaterialTheme.typography.bodySmall
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Показать внутренний редактор и терминал",
                        fontWeight = FontWeight.SemiBold
                    )
                    Switch(
                        checked = uiState.settings.showInternalEditorAndTerminal,
                        onCheckedChange = { viewModel.setDeveloperModeShowEditorTerminal(it) }
                    )
                }
            }
        }
    }
}
