package dev.miraclecode.app.core.effort

import dev.miraclecode.app.domain.model.AiModelSpec
import dev.miraclecode.app.domain.model.ApiCompatibilityType
import dev.miraclecode.app.domain.model.CombinedEffortConfig
import dev.miraclecode.app.domain.model.LayerEffortLevel
import dev.miraclecode.app.domain.model.ModelEffortLevel
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class EffortEngine @Inject constructor() {

    data class PreparedInferenceRequest(
        val effectiveSystemPrompt: String,
        val nativeApiParameters: JsonObject
    )

    fun buildInferenceParameters(
        baseRoleSystemPrompt: String,
        model: AiModelSpec,
        compatibilityType: ApiCompatibilityType,
        effortConfig: CombinedEffortConfig
    ): PreparedInferenceRequest {
        val injectedSystemPrompt = injectLayerEffortPrompt(
            basePrompt = baseRoleSystemPrompt,
            layer = effortConfig.layerEffort
        )

        val budgetTokens = if (effortConfig.modelEffort == ModelEffortLevel.CUSTOM_BUDGET) {
            effortConfig.customThinkingBudgetTokens
        } else {
            effortConfig.modelEffort.thinkingBudgetTokens
        }

        val nativeParams = buildJsonObject {
            if (model.supportsNativeReasoning) {
                when (compatibilityType) {
                    ApiCompatibilityType.ANTHROPIC_MESSAGES -> {
                        put("thinking", buildJsonObject {
                            put("type", "enabled")
                            put("budget_tokens", budgetTokens)
                        })
                    }
                    ApiCompatibilityType.GOOGLE_GEMINI -> {
                        put("thinking_config", buildJsonObject {
                            put("include_thoughts", true)
                            put("thinking_budget", budgetTokens)
                        })
                    }
                    else -> {
                        effortConfig.modelEffort.openAiReasoningEffort?.let {
                            put("reasoning_effort", it)
                        }
                        put("max_completion_tokens", (model.maxOutputTokens + budgetTokens).coerceAtMost(65_536))
                    }
                }
            } else {
                put("temperature", JsonPrimitive(effortConfig.modelEffort.defaultTemperature))
                put("top_p", JsonPrimitive(effortConfig.modelEffort.defaultTopP))
                put("max_tokens", JsonPrimitive(model.maxOutputTokens))
            }
        }

        return PreparedInferenceRequest(
            effectiveSystemPrompt = injectedSystemPrompt,
            nativeApiParameters = nativeParams
        )
    }

    fun injectLayerEffortPrompt(
        basePrompt: String,
        layer: LayerEffortLevel
    ): String {
        val metaLayerDirective = when (layer) {
            LayerEffortLevel.OFF -> ""

            LayerEffortLevel.LAYER_1_STRUCTURED -> """
                [MIRACLE META-COGNITIVE LAYER 1: STRUCTURED ARCHITECTURE]
                Перед написанием любого финального кода или ответа выполни структурированное проектирование:
                1. Сформулируй архитектурный план решения, модули и контракты данных.
                2. Перечисли граничные случаи (edge cases), состояния гонки, ошибки сети/файловой системы и пустые входы.
                3. Только после фиксации плана сгенерируй чистый, модульный код, учитывающий все выявленные граничные случаи.
            """.trimIndent()

            LayerEffortLevel.LAYER_2_DEEP_CRITIQUE -> """
                [MIRACLE META-COGNITIVE LAYER 2: INTERNAL SELF-CRITIQUE LOOP]
                Ты обязан пройти полный четырехфазный цикл верификации перед выдачей результата:
                - Фаза 1 (Draft): Спроектируй архитектуру и черновую реализацию всех компонентов.
                - Фаза 2 (Self-Critique): Проведи жесткое код-ревью собственного черновика. Проверь нарушения Clean Architecture, утечки корутин, блокировки UI-потока, необработанные исключения и неполные импорты.
                - Фаза 3 (Refactor): Перепиши уязвимые или неоптимальные участки, устранив все замечания из Фазы 2.
                - Фаза 4 (Final Output): Выдай исключительно отполированный, готовый к продакшену финальный код и краткое резюме исправленных в ходе самопроверки узких мест.
            """.trimIndent()

            LayerEffortLevel.LAYER_3_GODLIKE_EXHAUSTIVE -> """
                [MIRACLE META-COGNITIVE LAYER 3: GODLIKE EXHAUSTIVE VERIFICATION]
                Активирован максимальный мета-когнитивный режим верификации Principal Systems Engineer:
                1. Многошаговая декомпозиция: Разбей задачу на атомарные подсистемы, определи инварианты состояния и граф зависимостей.
                2. Статический анализ типов и контрактов: Мысленно скомпилируй каждый класс, проверь null-safety, ковариантность дженериков, сериализацию и совместимость сигнатур.
                3. Аудит безопасности (Security Threat Model): Исключи инъекции команд в терминал, path traversal в песочнице, утечки API-ключей в логах и небезопасное хранение секретов.
                4. Профилирование производительности и памяти: Оптимизируй рекомпозиции в Jetpack Compose (@Stable/@Immutable), избегай лишних аллокаций в горячих циклах и обеспечь корректную отмену корутин (structured concurrency).
                5. Выдай эталонную, исчерпывающую реализацию без заглушек (TODO/placeholders).
            """.trimIndent()
        }

        return if (metaLayerDirective.isEmpty()) {
            basePrompt.trim()
        } else {
            "${basePrompt.trim()}\n\n$metaLayerDirective"
        }
    }
}
