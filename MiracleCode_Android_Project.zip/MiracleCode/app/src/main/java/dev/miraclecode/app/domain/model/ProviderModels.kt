package dev.miraclecode.app.domain.model

import kotlinx.serialization.Serializable

enum class ApiCompatibilityType {
    OPENAI_COMPATIBLE,
    ANTHROPIC_MESSAGES,
    GOOGLE_GEMINI,
    OLLAMA_NATIVE
}

@Serializable
data class ProviderConfig(
    val id: String,
    val name: String,
    val baseUrl: String,
    val modelsEndpoint: String = "/v1/models",
    val chatEndpoint: String = "/v1/chat/completions",
    val compatibilityType: ApiCompatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE,
    val customHeaders: Map<String, String> = emptyMap(),
    val isPreset: Boolean = true,
    val isEnabled: Boolean = true,
    val lastSyncedEpochMs: Long = 0L
)

@Serializable
data class AiModelSpec(
    val id: String,
    val providerId: String,
    val displayName: String,
    val contextWindowTokens: Int = 128_000,
    val maxOutputTokens: Int = 8_192,
    val supportsVision: Boolean = false,
    val supportsToolCalling: Boolean = true,
    val supportsNativeReasoning: Boolean = false,
    val inputCostPerMillionUsd: Double = 0.0,
    val outputCostPerMillionUsd: Double = 0.0
)

object PresetProviders {
    val ALL: List<ProviderConfig> = listOf(
        ProviderConfig(
            id = "openai",
            name = "OpenAI",
            baseUrl = "https://api.openai.com",
            modelsEndpoint = "/v1/models",
            chatEndpoint = "/v1/chat/completions",
            compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE
        ),
        ProviderConfig(
            id = "anthropic",
            name = "Anthropic",
            baseUrl = "https://api.anthropic.com",
            modelsEndpoint = "/v1/models",
            chatEndpoint = "/v1/messages",
            compatibilityType = ApiCompatibilityType.ANTHROPIC_MESSAGES,
            customHeaders = mapOf("anthropic-version" to "2023-06-01")
        ),
        ProviderConfig(
            id = "gemini",
            name = "Google Gemini",
            baseUrl = "https://generativelanguage.googleapis.com",
            modelsEndpoint = "/v1beta/models",
            chatEndpoint = "/v1beta/openai/chat/completions",
            compatibilityType = ApiCompatibilityType.GOOGLE_GEMINI
        ),
        ProviderConfig(
            id = "openrouter",
            name = "OpenRouter",
            baseUrl = "https://openrouter.ai/api",
            modelsEndpoint = "/v1/models",
            chatEndpoint = "/v1/chat/completions",
            compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE,
            customHeaders = mapOf("X-Title" to "Miracle Code Android")
        ),
        ProviderConfig(
            id = "deepseek",
            name = "DeepSeek",
            baseUrl = "https://api.deepseek.com",
            modelsEndpoint = "/v1/models",
            chatEndpoint = "/v1/chat/completions",
            compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE
        ),
        ProviderConfig(
            id = "groq",
            name = "Groq",
            baseUrl = "https://api.groq.com/openai",
            modelsEndpoint = "/v1/models",
            chatEndpoint = "/v1/chat/completions",
            compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE
        ),
        ProviderConfig(
            id = "mistral",
            name = "Mistral AI",
            baseUrl = "https://api.mistral.ai",
            modelsEndpoint = "/v1/models",
            chatEndpoint = "/v1/chat/completions",
            compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE
        ),
        ProviderConfig(
            id = "xai",
            name = "xAI (Grok)",
            baseUrl = "https://api.x.ai",
            modelsEndpoint = "/v1/models",
            chatEndpoint = "/v1/chat/completions",
            compatibilityType = ApiCompatibilityType.OPENAI_COMPATIBLE
        ),
        ProviderConfig(
            id = "ollama",
            name = "Ollama (Local / LAN)",
            baseUrl = "http://127.0.0.1:11434",
            modelsEndpoint = "/api/tags",
            chatEndpoint = "/v1/chat/completions",
            compatibilityType = ApiCompatibilityType.OLLAMA_NATIVE
        )
    )
}
