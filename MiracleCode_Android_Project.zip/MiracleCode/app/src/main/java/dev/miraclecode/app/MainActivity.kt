package dev.miraclecode.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.AndroidEntryPoint
import dev.miraclecode.app.ui.screens.MiracleCodeMainScreen
import dev.miraclecode.app.ui.theme.MiracleCodeTheme
import dev.miraclecode.app.ui.viewmodel.MiracleMainViewModel

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MiracleMainViewModel = hiltViewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            MiracleCodeTheme(
                themeMode = uiState.settings.themeMode,
                dynamicColor = uiState.settings.dynamicColorEnabled
            ) {
                MiracleCodeMainScreen(
                    uiState = uiState,
                    viewModel = viewModel
                )
            }
        }
    }
}
