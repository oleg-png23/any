package dev.miraclecode.app.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "providers")
data class ProviderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val baseUrl: String,
    val modelsEndpoint: String,
    val chatEndpoint: String,
    val compatibilityType: String,
    val customHeadersJson: String,
    val isPreset: Boolean,
    val isEnabled: Boolean,
    val lastSyncedEpochMs: Long
)

@Entity(tableName = "ai_models", primaryKeys = ["id", "providerId"])
data class AiModelEntity(
    val id: String,
    val providerId: String,
    val displayName: String,
    val contextWindowTokens: Int,
    val maxOutputTokens: Int,
    val supportsVision: Boolean,
    val supportsToolCalling: Boolean,
    val supportsNativeReasoning: Boolean,
    val inputCostPerMillionUsd: Double,
    val outputCostPerMillionUsd: Double
)

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey val sessionId: String,
    val title: String,
    val executionMode: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
    val totalTokensUsed: Int,
    val totalCostUsd: Double
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val messageId: String,
    val sessionId: String,
    val senderRole: String,
    val agentName: String,
    val modelId: String,
    val content: String,
    val sideBySideGroupId: String?,
    val isSelectedBestInSideBySide: Boolean,
    val previewType: String?,
    val previewContent: String?,
    val createdAtEpochMs: Long
)

@Entity(tableName = "fs_snapshots")
data class FsSnapshotEntity(
    @PrimaryKey val snapshotId: String,
    val sessionId: String,
    val label: String,
    val agentId: String,
    val filesHash: String,
    val archivePath: String,
    val createdAtEpochMs: Long
)

@Dao
interface MiracleDao {
    @Query("SELECT * FROM providers ORDER BY isPreset DESC, name ASC")
    fun observeProviders(): Flow<List<ProviderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProviders(providers: List<ProviderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProvider(provider: ProviderEntity)

    @Query("SELECT * FROM ai_models WHERE providerId = :providerId ORDER BY displayName ASC")
    fun observeModelsByProvider(providerId: String): Flow<List<AiModelEntity>>

    @Query("SELECT * FROM ai_models WHERE displayName LIKE '%' || :searchQuery || '%' OR id LIKE '%' || :searchQuery || '%' ORDER BY providerId, displayName ASC")
    fun searchModels(searchQuery: String): Flow<List<AiModelEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun replaceModelsForProvider(models: List<AiModelEntity>)

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY createdAtEpochMs ASC")
    fun observeMessages(sessionId: String): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Query("UPDATE chat_messages SET isSelectedBestInSideBySide = (messageId = :chosenMessageId) WHERE sideBySideGroupId = :groupId")
    suspend fun markSideBySideWinner(groupId: String, chosenMessageId: String)

    @Query("SELECT * FROM fs_snapshots WHERE sessionId = :sessionId ORDER BY createdAtEpochMs DESC")
    fun observeSnapshots(sessionId: String): Flow<List<FsSnapshotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: FsSnapshotEntity)
}

@Database(
    entities = [
        ProviderEntity::class,
        AiModelEntity::class,
        ChatSessionEntity::class,
        ChatMessageEntity::class,
        FsSnapshotEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class MiracleDatabase : RoomDatabase() {
    abstract fun miracleDao(): MiracleDao
}
