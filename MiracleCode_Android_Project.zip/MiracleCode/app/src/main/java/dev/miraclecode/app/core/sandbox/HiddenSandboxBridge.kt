package dev.miraclecode.app.core.sandbox

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import dev.miraclecode.app.data.local.FsSnapshotEntity
import dev.miraclecode.app.data.local.MiracleDao
import dev.miraclecode.app.domain.model.FsSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.inject.Inject
import javax.inject.Singleton

data class SandboxCommandResult(
    val command: String,
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val durationMs: Long
) {
    val isSuccess: Boolean get() = exitCode == 0
}

data class VirtualFileEntry(
    val relativePath: String,
    val sizeBytes: Long,
    val isDirectory: Boolean
)

@Singleton
class HiddenSandboxBridge @Inject constructor(
    @ApplicationContext private val context: Context,
    private val miracleDao: MiracleDao
) {
    private val workspaceRoot: File by lazy {
        File(context.filesDir, "sandbox_workspace").apply { mkdirs() }
    }
    private val snapshotsRoot: File by lazy {
        File(context.filesDir, "sandbox_snapshots").apply { mkdirs() }
    }

    private val _terminalLogs = MutableStateFlow<List<String>>(
        listOf("[Miracle Sandbox] Linux/PRoot Isolated Environment Initialized.")
    )
    val terminalLogs: StateFlow<List<String>> = _terminalLogs.asStateFlow()

    suspend fun listWorkspaceFiles(): List<VirtualFileEntry> = withContext(Dispatchers.IO) {
        if (!workspaceRoot.exists()) return@withContext emptyList()
        workspaceRoot.walkTopDown()
            .filter { it != workspaceRoot }
            .map { file ->
                VirtualFileEntry(
                    relativePath = file.relativeTo(workspaceRoot).path,
                    sizeBytes = if (file.isFile) file.length() else 0L,
                    isDirectory = file.isDirectory
                )
            }
            .toList()
    }

    suspend fun readFile(relativePath: String): String = withContext(Dispatchers.IO) {
        val target = resolveSafeFile(relativePath)
        if (target.exists() && target.isFile) target.readText() else ""
    }

    suspend fun writeFileWithSnapshot(
        sessionId: String,
        agentId: String,
        relativePath: String,
        content: String
    ): FsSnapshot = withContext(Dispatchers.IO) {
        val snapshot = createSnapshot(
            sessionId = sessionId,
            agentId = agentId,
            label = "Before writing $relativePath"
        )
        val target = resolveSafeFile(relativePath)
        target.parentFile?.mkdirs()
        target.writeText(content)
        appendLog("[$agentId] wrote file: $relativePath (${content.lines().size} lines)")
        snapshot
    }

    suspend fun executeCommand(
        agentId: String,
        command: String,
        timeoutMs: Long = 30_000L
    ): SandboxCommandResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        appendLog("[$agentId] $ $command")
        return@withContext try {
            val process = ProcessBuilder("sh", "-c", command)
                .directory(workspaceRoot)
                .redirectErrorStream(false)
                .start()

            val stdout = process.inputStream.bufferedReader().readText()
            val stderr = process.errorStream.bufferedReader().readText()
            val exitCode = process.waitFor()
            val duration = System.currentTimeMillis() - start

            if (stdout.isNotBlank()) appendLog(stdout.trim())
            if (stderr.isNotBlank()) appendLog("[STDERR] ${stderr.trim()}")

            SandboxCommandResult(
                command = command,
                exitCode = exitCode,
                stdout = stdout,
                stderr = stderr,
                durationMs = duration
            )
        } catch (e: Exception) {
            val err = e.message ?: "Process execution error"
            appendLog("[STDERR] $err")
            SandboxCommandResult(
                command = command,
                exitCode = -1,
                stdout = "",
                stderr = err,
                durationMs = System.currentTimeMillis() - start
            )
        }
    }

    suspend fun createSnapshot(
        sessionId: String,
        agentId: String,
        label: String
    ): FsSnapshot = withContext(Dispatchers.IO) {
        val snapshotId = "snap_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(5)}"
        val archiveFile = File(snapshotsRoot, "$snapshotId.zip")
        val digest = MessageDigest.getInstance("SHA-256")

        ZipOutputStream(archiveFile.outputStream().buffered()).use { zos ->
            workspaceRoot.walkTopDown().filter { it.isFile }.forEach { file ->
                val relPath = file.relativeTo(workspaceRoot).path
                val bytes = file.readBytes()
                digest.update(relPath.toByteArray())
                digest.update(bytes)
                zos.putNextEntry(ZipEntry(relPath))
                zos.write(bytes)
                zos.closeEntry()
            }
        }

        val hashHex = digest.digest().joinToString("") { "%02x".format(it) }.take(16)
        val now = System.currentTimeMillis()
        val entity = FsSnapshotEntity(
            snapshotId = snapshotId,
            sessionId = sessionId,
            label = label,
            agentId = agentId,
            filesHash = hashHex,
            archivePath = archiveFile.absolutePath,
            createdAtEpochMs = now
        )
        miracleDao.insertSnapshot(entity)

        FsSnapshot(
            snapshotId = snapshotId,
            label = label,
            createdAtEpochMs = now,
            agentId = agentId,
            filesHash = hashHex,
            fileArchivePath = archiveFile.absolutePath
        )
    }

    suspend fun rollbackToSnapshot(snapshot: FsSnapshot): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val archive = File(snapshot.fileArchivePath)
            require(archive.exists()) { "Файл чекпоинта не найден: ${snapshot.snapshotId}" }
            workspaceRoot.deleteRecursively()
            workspaceRoot.mkdirs()

            ZipInputStream(archive.inputStream().buffered()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val outFile = resolveSafeFile(entry.name)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        outFile.outputStream().use { zis.copyTo(it) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            appendLog("[Time Travel] Проект откатан к чекпоинту '${snapshot.label}' (${snapshot.filesHash})")
        }
    }

    suspend fun exportProjectToZip(targetZipFile: File): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            ZipOutputStream(targetZipFile.outputStream().buffered()).use { zos ->
                workspaceRoot.walkTopDown().filter { it.isFile }.forEach { file ->
                    val relPath = file.relativeTo(workspaceRoot).path
                    zos.putNextEntry(ZipEntry(relPath))
                    file.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            targetZipFile
        }
    }

    private fun resolveSafeFile(relativePath: String): File {
        val target = File(workspaceRoot, relativePath).canonicalFile
        val rootCanonical = workspaceRoot.canonicalFile
        require(target.path.startsWith(rootCanonical.path)) {
            "Path traversal заблокирован политикой безопасности песочницы: $relativePath"
        }
        return target
    }

    private fun appendLog(line: String) {
        _terminalLogs.value = (_terminalLogs.value + line).takeLast(500)
    }
}
