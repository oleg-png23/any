package dev.miraclecode.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.miraclecode.app.core.orchestration.OrchestrationEngine
import dev.miraclecode.app.core.orchestration.OrchestrationResult
import dev.miraclecode.app.core.provider.ProviderManager
import dev.miraclecode.app.core.sandbox.HiddenSandboxBridge
import dev.miraclecode.app.core.sandbox.VirtualFileEntry
import dev.miraclecode.app.data.local.MiracleUserSettings
import dev.miraclecode.app.data.local.ThemeMode
import dev.miraclecode.app.data.local.UserPreferencesDataStore
import dev.miraclecode.app.domain.model.AgentGraphNode
import dev.miraclecode.app.domain.model.AgentParticipant
import dev.miraclecode.app.domain.model.AiModelSpec
import dev.miraclecode.app.domain.model.ApiCompatibilityType
import dev.miraclecode.app.domain.model.CombinedEffortConfig
import dev.miraclecode.app.domain.model.ExecutionMode
import dev.miraclecode.app.domain.model.FsSnapshot
import dev.miraclecode.app.domain.model.LayerEffortLevel
import dev.miraclecode.app.domain.model.ModelEffortLevel
import dev.miraclecode.app.domain.model.ProviderConfig
import dev.miraclecode.app.domain.model.SubAgentSpecialty
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MiracleUiState(
    val settings: MiracleUserSettings = MiracleUserSettings(),
    val providers: List<ProviderConfig> = emptyList(),
    val models: List<AiModelSpec> = emptyList(),
    val modelSearchQuery: String = "",
    val activeGraphNodes: List<AgentGraphNode> = emptyList(),
    val lastOrchestrationResult: OrchestrationResult? = null,
    val selectedSideBySideWinnerIndex: Int? = null,
    val workspaceFiles: List<VirtualFileEntry> = emptyList(),
    val selectedEditorFilePath: String = "src/MainSolution.kt",
    val selectedEditorFileContent: String = "",
    val terminalLogs: List<String> = emptyList(),
    val snapshots: List<FsSnapshot> = emptyList(),
    val isBusy: Boolean = false,
    val statusBanner: String? = null
)

@HiltViewModel
class MiracleMainViewModel @Inject constructor(
    private val preferences: UserPreferencesDataStore,
    private val providerManager: ProviderManager,
    private val orchestrationEngine: OrchestrationEngine,
    private val sandboxBridge: HiddenSandboxBridge
) : ViewModel() {

    private val searchQueryFlow = MutableStateFlow("")
    private val lastResultFlow = MutableStateFlow<OrchestrationResult?>(null)
    private val sideBySideWinnerFlow = MutableStateFlow<Int?>(null)
    private val editorFileFlow = MutableStateFlow("src/MainSolution.kt")
    private val editorContentFlow = MutableStateFlow("// Скрытый редактор Miracle Code\n")
    private val workspaceFilesFlow = MutableStateFlow<List<VirtualFileEntry>>(emptyList())
    private val snapshotsFlow = MutableStateFlow<List<FsSnapshot>>(emptyList())
    private val busyFlow = MutableStateFlow(false)
    private val bannerFlow = MutableStateFlow<String?>(null)

    private val defaultModels = listOf(
        AiModelSpec(
            id = "claude-3-7-sonnet-latest",
            providerId = "anthropic",
            displayName = "Claude 3.7 Sonnet (Thinking)",
            contextWindowTokens = 200_000,
            supportsVision = true,
            supportsNativeReasoning = true,
            inputCostPerMillionUsd = 3.0,
            outputCostPerMillionUsd = 15.0
        ),
        AiModelSpec(
            id = "gpt-4o",
            providerId = "openai",
            displayName = "GPT-4o Omni",
            contextWindowTokens = 128_000,
            supportsVision = true,
            supportsNativeReasoning = false,
            inputCostPerMillionUsd = 2.5,
            outputCostPerMillionUsd = 10.0
        ),
        AiModelSpec(
            id = "gemini-2.5-pro",
            providerId = "gemini",
            displayName = "Gemini 2.5 Pro",
            contextWindowTokens = 1_048_576,
            supportsVision = true,
            supportsNativeReasoning = true,
            inputCostPerMillionUsd = 1.25,
            outputCostPerMillionUsd = 10.0
        ),
        AiModelSpec(
            id = "deepseek-reasoner",
            providerId = "deepseek",
            displayName = "DeepSeek R1 Reasoner",
            contextWindowTokens = 128_000,
            supportsVision = false,
            supportsNativeReasoning = true,
            inputCostPerMillionUsd = 0.55,
            outputCostPerMillionUsd = 2.19
        )
    )

    val uiState: StateFlow<MiracleUiState> = combine(
        preferences.settingsFlow,
        providerManager.observeProviders(),
        orchestrationEngine.agentGraphNodes,
        sandboxBridge.terminalLogs,
        busyFlow
    ) { settings, providers, graphNodes, termLogs, isBusy ->
        MiracleUiState(
            settings = settings,
            providers = providers,
            models = defaultModels,
            modelSearchQuery = searchQueryFlow.value,
            activeGraphNodes = graphNodes,
            lastOrchestrationResult = lastResultFlow.value,
            selectedSideBySideWinnerIndex = sideBySideWinnerFlow.value,
            workspaceFiles = workspaceFilesFlow.value,
            selectedEditorFilePath = editorFileFlow.value,
            selectedEditorFileContent = editorContentFlow.value,
            terminalLogs = termLogs,
            snapshots = snapshotsFlow.value,
            isBusy = isBusy,
            statusBanner = bannerFlow.value
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MiracleUiState())

    init {
        viewModelScope.launch {
            providerManager.ensurePresetsSeeded()
            refreshSandboxState()
        }
    }

    fun setExecutionMode(mode: ExecutionMode) {
        viewModelScope.launch { preferences.setExecutionMode(mode) }
    }

    fun setModelEffort(level: ModelEffortLevel, customBudget: Int? = null) {
        viewModelScope.launch { preferences.setModelEffort(level, customBudget) }
    }

    fun setLayerEffort(level: LayerEffortLevel) {
        viewModelScope.launch { preferences.setLayerEffort(level) }
    }

    fun setDeveloperModeShowEditorTerminal(enabled: Boolean) {
        viewModelScope.launch {
            preferences.setShowInternalEditorAndTerminal(enabled)
            refreshSandboxState()
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferences.setThemeMode(mode) }
    }

    fun setDynamicColor(enabled: Boolean) {
        viewModelScope.launch { preferences.setDynamicColor(enabled) }
    }

    fun saveApiKeyAndFetchModels(provider: ProviderConfig, apiKey: String) {
        viewModelScope.launch {
            busyFlow.value = true
            val result = providerManager.setApiKeyAndAutoFetch(provider, apiKey)
            bannerFlow.value = result.fold(
                onSuccess = { "Загружено ${it.size} моделей от ${provider.name}" },
                onFailure = { "Ключ сохранен локально (Keystore). Ошибка сети при автозагрузке: ${it.message}" }
            )
            busyFlow.value = false
        }
    }

    fun addCustomProvider(
        name: String,
        baseUrl: String,
        apiKey: String,
        compatibilityType: ApiCompatibilityType,
        headers: Map<String, String>
    ) {
        viewModelScope.launch {
            busyFlow.value = true
            providerManager.addCustomProviderAndFetchModels(name, baseUrl, apiKey, compatibilityType, headers)
            busyFlow.value = false
        }
    }

    fun selectSideBySideWinner(index: Int) {
        sideBySideWinnerFlow.value = index
    }

    fun executePrompt(userPrompt: String) {
        if (userPrompt.isBlank()) return
        viewModelScope.launch {
            busyFlow.value = true
            sideBySideWinnerFlow.value = null
            val currentSettings = uiState.value.settings
            val effort = CombinedEffortConfig(
                modelEffort = currentSettings.activeModelEffort,
                customThinkingBudgetTokens = currentSettings.customThinkingBudgetTokens,
                layerEffort = currentSettings.activeLayerEffort
            )

            val participants = defaultModels.mapIndexed { idx, spec ->
                val specialty = SubAgentSpecialty.entries[(idx + 1) % SubAgentSpecialty.entries.size]
                AgentParticipant(
                    agentId = "agent_${spec.id}",
                    displayName = spec.displayName,
                    role = specialty,
                    modelSpec = spec,
                    effortConfig = effort
                )
            }

            val sessionId = "session_default"
            val result = when (currentSettings.activeExecutionMode) {
                ExecutionMode.SOLO -> orchestrationEngine.runSoloMode(
                    sessionId = sessionId,
                    agent = participants.first(),
                    userPrompt = userPrompt
                )
                ExecutionMode.SIDE_BY_SIDE -> orchestrationEngine.runSideBySideMode(
                    agents = participants.take(3),
                    userPrompt = userPrompt
                )
                ExecutionMode.AGENT_MIX -> orchestrationEngine.runAgentMixMode(
                    agents = participants.take(3),
                    userPrompt = userPrompt,
                    rounds = 2
                )
                ExecutionMode.ORCHESTRA -> orchestrationEngine.runOrchestraMode(
                    leadArchitect = participants.first().copy(role = SubAgentSpecialty.ORCHESTRATOR),
                    subAgents = listOf(
                        participants[0].copy(agentId = "sub_backend", role = SubAgentSpecialty.BACKEND),
                        participants[1].copy(agentId = "sub_ui", role = SubAgentSpecialty.UI_UX),
                        participants[2].copy(agentId = "sub_qa", role = SubAgentSpecialty.QA_TESTING),
                        participants[3].copy(agentId = "sub_sec", role = SubAgentSpecialty.SECURITY)
                    ),
                    userPrompt = userPrompt
                )
                ExecutionMode.AUTONOMOUS_AGENT -> orchestrationEngine.runAutonomousAgentMode(
                    sessionId = sessionId,
                    autonomousAgent = participants.first().copy(role = SubAgentSpecialty.ORCHESTRATOR),
                    subAgentPool = participants,
                    userPrompt = userPrompt,
                    maxAutoHealIterations = currentSettings.autoHealMaxIterations
                )
            }

            lastResultFlow.value = result
            refreshSandboxState()
            busyFlow.value = false
        }
    }

    fun runManualTerminalCommand(cmd: String) {
        viewModelScope.launch {
            sandboxBridge.executeCommand(agentId = "DeveloperUser", command = cmd)
            refreshSandboxState()
        }
    }

    fun rollbackToSnapshot(snapshot: FsSnapshot) {
        viewModelScope.launch {
            sandboxBridge.rollbackToSnapshot(snapshot)
            refreshSandboxState()
        }
    }

    private suspend fun refreshSandboxState() {
        workspaceFilesFlow.value = sandboxBridge.listWorkspaceFiles()
        editorContentFlow.value = sandboxBridge.readFile(editorFileFlow.value)
    }
}
