package dev.miraclecode.app.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Хранилище API-ключей в Android Keystore через EncryptedSharedPreferences (AES256-GCM / AES256-SIV).
 */
@Singleton
class EncryptedKeyVault @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            "miracle_code_secure_api_keys",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun saveApiKey(providerId: String, apiKey: String) {
        prefs.edit().putString(keyFor(providerId), apiKey.trim()).apply()
    }

    fun getApiKey(providerId: String): String? {
        return prefs.getString(keyFor(providerId), null)?.takeIf { it.isNotBlank() }
    }

    fun hasApiKey(providerId: String): Boolean {
        return !getApiKey(providerId).isNullOrBlank()
    }

    fun removeApiKey(providerId: String) {
        prefs.edit().remove(keyFor(providerId)).apply()
    }

    private fun keyFor(providerId: String): String = "api_key_$providerId"
}
