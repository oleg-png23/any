package dev.miraclecode.app

import dev.miraclecode.app.core.effort.EffortEngine
import dev.miraclecode.app.domain.model.AiModelSpec
import dev.miraclecode.app.domain.model.ApiCompatibilityType
import dev.miraclecode.app.domain.model.CombinedEffortConfig
import dev.miraclecode.app.domain.model.LayerEffortLevel
import dev.miraclecode.app.domain.model.ModelEffortLevel
import org.junit.Assert.assertTrue
import org.junit.Test

class EffortEngineTest {

    private val engine = EffortEngine()

    @Test
    fun `combines native ModelEffort with Meta-Cognitive Layer 3 system injection`() {
        val model = AiModelSpec(
            id = "claude-3-7-sonnet",
            providerId = "anthropic",
            displayName = "Claude 3.7 Sonnet",
            supportsNativeReasoning = true
        )
        val config = CombinedEffortConfig(
            modelEffort = ModelEffortLevel.HIGH,
            layerEffort = LayerEffortLevel.LAYER_3_GODLIKE_EXHAUSTIVE
        )

        val result = engine.buildInferenceParameters(
            baseRoleSystemPrompt = "You are an Android Architect.",
            model = model,
            compatibilityType = ApiCompatibilityType.ANTHROPIC_MESSAGES,
            effortConfig = config
        )

        assertTrue(result.effectiveSystemPrompt.contains("GODLIKE EXHAUSTIVE VERIFICATION"))
        assertTrue(result.nativeApiParameters.toString().contains("budget_tokens"))
    }
}
